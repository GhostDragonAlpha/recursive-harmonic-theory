# Fractal Recursive Harmonic Space-Time Theory Project

This repository contains all the necessary files for the Fractal Recursive Harmonic Space-Time Theory project, integrating various components:
- **The Anti-Golden Ratio**: Structured minima in prime number distributions (The Anti-Golden Ratio_ Structured Minima in Prime Number Distributions v3.txt)
- **Executive Summary**: Unified Fractal Recursive Harmonic Space-Time Theory (executive_summary.pdf)
- **Theory Framework**: Fractal Scale-Invariant Space-Time Theory (theory_framework.pdf)
- **Unified Mathematical Framework**: Integrating golden ratio, pi, and additional mathematical constants (unified_mathematical_framework.pdf)
- **Comprehensive Unified Framework**: Final integrated document (comprehensive_unified_framework.pdf)
- **Irrational Numbers and Forces**: Unified harmonic perspective (irrational_numbers_and_forces.md)

## Structure

- `The Anti-Golden Ratio_ Structured Minima in Prime Number Distributions v3.txt`: Detailed paper on Anti-Golden Ratio.
- `executive_summary.pdf`: Executive summary of the unified theory.
- `theory_framework.pdf`: Core theoretical framework document.
- `unified_mathematical_framework.pdf`: Detailed mathematical framework.
- `comprehensive_unified_framework.pdf`: Comprehensive unified theory document.
- `irrational_numbers_and_forces.md`: Markdown document on irrational numbers and forces.

## How to Use

1. Clone or download the repository.
2. Review each document as needed.
3. For GitHub, simply add this repository to a new GitHub project.

## License

Add your preferred license here.

